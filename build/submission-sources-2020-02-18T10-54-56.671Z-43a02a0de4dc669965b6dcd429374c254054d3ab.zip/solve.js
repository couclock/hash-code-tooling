const debug = require("debug")("solve");
const _ = require("lodash");
const gridUtils = require("./grid-utils");

function solve(problem, file) {
  // destructure this!
  return [];
}

module.exports = solve;
